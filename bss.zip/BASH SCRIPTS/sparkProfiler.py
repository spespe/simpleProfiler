#Created by Pietro Speri
#EMAIL: pietro.speri@sce.com pietro.speri@infosys.com
#CREATED ON Jan 8th 2019 

import sys
import datetime
from pyspark import SparkContext, SparkConf
from pyspark.sql import *
from pyspark.sql.types import *

db=sys.argv[1]
table=sys.argv[2]
column=sys.argv[3]

job_name="Profiler_"+str(db)+"_"+str(table)+"_"+str(column)
	
def profiler(db,table,column):
	sep="|"
	tablename=db+'.'+table
	rdd=hc.table(str(tablename)).select(str(column)).rdd
	rddCount=rdd.count()
	rddDistinctCount=rdd.distinct().count()
	isDistinct="TRUE" if rddCount==rddDistinctCount else "FALSE"
	blanks=rdd.filter(lambda x:len((str(x).strip()))==0).count()
	hasBlanks="FALSE" if str(blanks)=="0" else "TRUE"
	nulls=rdd.filter(lambda x: x==None).count()
	hasNulls="FALSE" if(str(nulls)=="0") else "TRUE"
	maxLength=rdd.reduce(lambda x,y: len(str(x)) if len(str(x)) > len(str(y)) else len(str(y)))
	minLength=rdd.reduce(lambda x,y: len(str(x)) if len(str(x)) < len(str(y)) else len(str(y)))
	maxLengthTrimmed=rdd.filter(lambda x: x!=None).reduce(lambda x,y: len(str(x)) if len(str(x)) > len(str(y)) else len(str(y)))
	minLengthTrimmed=rdd.filter(lambda x: x!=None).reduce(lambda x,y: len(str(x)) if len(str(x)) < len(str(y)) else len(str(y)))
	print(db+sep+table+sep+column+sep+isDistinct+sep+hasBlanks+sep+hasNulls+sep+str(maxLength)+sep+str(minLength))

if __name__ == '__main__':
	conf = SparkConf().setAppName(job_name)
	sc = SparkContext(conf=conf)
	sc.setJobGroup(job_name, "PYTHON PROFILER")
	hc=HiveContext(sc)
	profiler(str(db),str(table),str(column))
