#!/bin/bash
##CREATED BY: PIETRO SPERI
##CREATION DATE: 07/27/2018
##CONTACT EMAIL: pietro.speri@sce.com - pietro.speri@infosys.com

NUM=1
LIMIT=500
LOCAL_PATH=/sourcefiles/GRIDMOD/CPR_DATA_LOAD/set1/
HADOOP_PATH=/data/landing/processing/der_cpr_2011_${NUM}
LIST=(`ls *.gz`)
LOGINFO=${0}_INFO.log

for FILE in ${LIST[@]}; do
        WC=`hadoop fs -ls ${HADOOP_PATH} | wc -l`
        if [[ ${WC} -gt ${LIMIT} ]]; then
                NUM=$((NUM+1))
                HADOOP_PATH=/data/landing/processing/der_cpr_2011_${NUM}
        fi
        CMD=`hadoop fs -ls ${HADOOP_PATH}`
        if [[ $? != 0 ]]; then
                CREATE_FOLDER=`hadoop fs -mkdir ${HADOOP_PATH}`
        fi
        NAME=`echo ${FILE} | cut -f1 -d '.'`
        CSV=`echo ${FILE} | cut -f2 -d '.'`
		DATE=`date +%Y/%m/%d" "%H:%M:%S`
        echo "${DATE} - MOVING THE FILE ${FILE} TO THE HDFS PATH ${HADOOP_PATH}" | tee -a ${LOGINFO}
        HADOOP=`zcat ${FILE} | hadoop fs -put - ${HADOOP_PATH}/${NAME}.${CSV}`
        RES=$?
        if [[ ${RES} != 0 ]]; then
                echo "ERROR FOUND WHILE MOVING THE FILES TO THE HDFS LOCATION [${HADOOP_PATH}]" | tee -a ${LOGINFO}
                exit 1
        fi
done

echo "THE SCRIPT FINISHED SUCCESSFULLY!!!"

