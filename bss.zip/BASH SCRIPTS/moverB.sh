#!/bin/bash
##CREATED BY: PIETRO SPERI
##CREATION DATE: 06/08/2018
##CONTACT EMAIL: pietro.speri@sce.com - pietro.speri@infosys.com
##VERSION 0.1
##MODIFICATIONS(if any): 

DATE=`date '+%Y-%m-%d %H:%M:%S'`
USER=`whoami`
APP_NAME=$(basename ${0})
APP_DIR=`pwd`
INPUT_FOLDER=/dsprojectsprd/SM_APM_N1_PROD/CSDB/INPUT
INPUT_FOLDER2=/dsprojectsprd/SM_APM_N1_PROD/CSDB/LANDING/INPUT
#INPUT_FOLDER3=/dsprojectsprd/SM_APM_N1_PROD/CSDB/LANDING/OUTPUT
LOGINFO=${APP_NAME}_LOG_INFO
LOGERROR=${APP_NAME}_LOG_ERROR
HOSTNAME=`hostname`
EXTENSION=zip

##CHECK ON THE INPUT FOLDERS
if [[ ! -d ${INPUT_FOLDER} ]] || [[ ! -d ${INPUT_FOLDER2} ]]; then
	echo -e "\e[0;31m ERROR ENCOUNTERED: THE FOLDER ${INPUT_FOLDER} or ${INPUT_FOLDER2} DOES NOT EXISTS. \e[0m" | tee -a ${LOG_ERROR}
	exit 1
fi

FIND=`find ${INPUT_FOLDER} -type f -name "*\\.${EXTENSION}"`
CHECK=$?
if [[ ${CHECK} != 0 ]]; then
	echo "ERROR LAUNCHING THE FIND COMMAND [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${DATE}]" | tee -a ${LOGERROR}
	exit 1
fi

echo "STARTING THE SCRIPT ${APP_NAME} [DIRECTORY: ${APP_DIR}] [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${DATE}]" | tee -a ${LOGINFO}
for FILE in ${FIND}; do
	#COPYING FILE ONE BY ONE
	CP=`cp -p ${FILE} ${INPUT_FOLDER2}`
	CHECK=$?
	if [[ ${CHECK} != 0 ]]; then
		echo "ERROR COPYING [FILE: ${FILE}] [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${DATE}]" | tee -a ${LOGERROR}
		exit 1
	fi
	##RUN COMMAND IN THE CURRENT FOLDER
	COMMAND=`/dsprojectsprd/SM_APM_N1_PROD/CSDB/SHL/csdb_runjob.ksh -param pCSDB_Monitor=PROD SM_APM_N1_PROD dsprojectsprd MASTER_CSDB_INPUT >/dev/null`   
	CHECK=$?
	if [[ ${CHECK} != 0 ]]; then
		echo "ERROR LAUNCHING THE COMMAND ON THE FILE ${FILE} [FILE: ${FILE}] [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${DATE}]" | tee -a ${LOGERROR}
		exit 1
	fi
	echo "SUCCESSFULLY LAUNCHED THE SCRIPT ON THE FILE ${FILE} [FILE: ${FILE}] [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${DATE}]" | tee -a ${LOGINFO}
done

echo "FINISHED [USER:${USER}] [HOSTNAME:${HOSTNAME}] [LOG DIRECTORY TOTAL SIZE MB:${LOG_DIR_SIZE}]" | tee -a ${LOGINFO}

	##THIS ONE IT IS GOING TO BE USED LATER ONE ON A DIFFERENT ENHANCEMENT
	##/dsprojectsprd/SM_APM_N1_PROD/CSDB/SHL/csdb_runjob.ksh -param pCSDB_Monitor=PROD SM_APM_N1_PROD dsprojectsprd MASTER_CSDB_OUTPUT >/dev/null
	