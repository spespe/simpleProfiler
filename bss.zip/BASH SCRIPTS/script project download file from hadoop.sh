#!/bin/bash
##CREATED BY: PIETRO SPERI


FOLDER1=/sourcefiles/WEATHER/RA/GridX_Usage_Catch_Up_tmp_
LOG=script_log.info
HADOOP_PATH=/data/prod_tmp/Gridx_Usage_Catch_Up_tmp/
LIST=(`cat $1`)

check(){
	CHECK=${1}
	if [[ ${CHECK} != 0 ]]; then
		echo "ERROR FOUND. EXITING. CHECK THE LOG FOR MORE INFORMATION ON THE FAILURE."
		exit 1
	fi
}

for DATE in ${LIST[@]}; do
	TIME=`date`
	FOLDER2="${FOLDER1}${DATE}/"
	echo "CREATING FOLDER: ${FOLDER2}" >> | tee -a ${LOG}
	FOLD=`mkdir ${FOLDER2}`
	C=$?
	check ${C}
	echo "DOWNLOADING FROM HADOOP ${HADOOP_PATH} SAVING TO ${FOLDER2}" >> | tee -a ${LOG}
	HADOOP=`hadoop fs -get ${HADOOP_PATH} ${FOLDER2}`
	C=$?
	check ${C}
	FILENAME=gridx_SCE_interval_1000_1_${DATE}
	echo "TIME: ${TIME} - CREATING FILE ${FOLDER2}/${FILENAME}" >> | tee -a ${LOG}
	FIND=`find ${FOLDER2} -type f | grep -v *.gzip | xargs -t -I {} cat >> ${FOLDER2}/${FILENAME} {}`
	C=$?
	check ${C}
	echo "ADDING HEADER TO ${FOLDER2}/${FILENAME}" >> | tee -a ${LOG}
	SED=`sed  -i '1i Serv_Pnt_Id|Rdng_Meas|Rdng_Dttm|Channel|Time_Zone|Interval_Frequency' ${FOLDER2}/${FILENAME}`
	C=$?
	check ${C}
	LENGTH=`wc –l ${FOLDER2}/${FILENAME}`
	C=$?
	check ${C}
	echo "${FOLDER2}/${FILENAME} LENGTH: ${LENGTH}" >> | tee -a ${LOG}
	TIME=`date +%H%M%S`
	C=$?
	check ${C}
	echo "CHANGING NAME TO ${FOLDER2}/${FILENAME}${TIME}.txt" >> | tee -a ${LOG}
	MV=`mv ${FOLDER2}/${FILENAME} ${FOLDER2}/${FILENAME}${TIME}.txt`
	C=$?
	check ${C}
	echo "ZIPPING FILE.." >> | tee -a ${LOG}
	GZIP=`gzip ${FILENAME}`
	C=$?
	check ${C}
	echo "REMOVING PREVIOUS FILES" >> | tee -a ${LOG}
	RM=`find ${FOLDER2}/ -type f | grep -v *.gz* | xargs -t -I {} rm -f {}`
	C=$?
	check ${C}
done
