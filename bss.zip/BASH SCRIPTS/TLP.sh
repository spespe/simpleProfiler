#!/bin/bash
##CREATED BY: PIETRO SPERI
##CREATION DATE: 10/10/2018
##CONTACT EMAIL: pietro.speri@sce.com - pietro.speri@infosys.com
##VERSION 0.1
##USAGE EXAMPLE: ksh script.ksh [PATTERN] ESPI [DATE1] 2018-10-10 [DATE2] 2018-10-21 [LOG FOLDER] /PATH/TO/LOGS

GREP="^### Job ENDED"
ADD=" WITH ERROR"
DATE=${1}
PROD_LOG_FOLDER=${2}
PATTERN=${3}
ERR=0
CORR=0
SEP="|"
#DATE2=${3}
FINAL_FILE=".PERCENTAGE_${PATTERN}_${DATE}_${DATE2}"
MAIL=${4}
RECIPIENTS="Santhosh.Kancherla@sce.com pietro.speri@sce.com"
TODAY=`date "+%Y-%m-%d"`
TODAYFORM=$(date -d ${TODAY} +"%Y%m%d")

if [[ $# -lt 2 ]]; then
	echo "THE SCRIPT NEEDS AT LEAST 2 ARGUMENTS."
	echo "EXAMPLE WITH ALL ARGUMENTS: ksh ${0} [DATE] 2018-10-10 [LOG FOLDER] /PATH/TO/LOGS [OPTIONAL: PATTERN] HADOOP_EEAT|HADOOP_PROP [OPTIONAL: MAIL] Y "
	echo "IF THE 3RD ARGUMENT [PATTERN] IS SPECIFIED, THE SCRIPT WILL SEARCH FOR THE PERCENTAGE OF THE JOBS FAILED AND SUCCEEDED FOR THAT PATTERN, GENERATING A WEEKLY FILE."
	echo "IF THE 4TH ARGUMENT IS SPECIFIED AS Y, THE SCRIPT WILL SEND AN EMAIL WITH THE GENERATED FILES AS ATTACHMENT TO THE PROVIDED RECIPIENTS."
    exit 1
fi

if [[ ! -d ${2} ]]; then
    echo "THE SPECIFIED FOLDER [${2}] DOES NOT EXIST."
    exit 1
fi

CHECK=`date "+%Y-%m-%d" -d "${DATE}" > /dev/null  2>&1`
RES=$?

DATE1FORM=$(date -d ${DATE} +"%Y%m%d")

CHECK2=`date "+%Y-%m-%d" -d "${DATE2}" > /dev/null  2>&1`
RES2=$?

RES2=$?
DATE2FORM=$(date -d ${DATE2} +"%Y%m%d")

if [[ ${RES} != 0 ]] || [[ ${RES2} != 0 ]] || [[ ${RES3} != 0 ]] || [[ ${#DATE} != 10 ]] || [[ ${#DATE2} != 10 ]] || [[ ! ${DATE} =~ "-" ]] || [[ ! ${DATE2} =~ "-" ]] || [[ ${DATE1FORM} -ge ${TODAYFORM} ]]; then
        echo "THE DATES PASSED ARE NOT IN THE CORRECT FORMAT. PLEASE PROVIDE THE DATE IN THE FORMAT YYYY-MM-DD. ALSO THE MAXIMUM DATE AVAILABLE IS TODAY'S DATE (EXCLUDED FROM THE COMPUTATION)."
        exit 1
fi

if [[ -f ${FINAL_FILE} ]]; then
        rm -f ${FINAL_FILE}
fi

IFS='|' read -r -a ARRAY <<< "${PATTERN}"



percentages()
{
	for APP in ${ARRAY[@]}; do
		
	done
}



failures_check()
{
		echo "FINDING LOGS FOR JOBS ENDED BETWEEN ${DATE} 00:00:00 AM AND ${DAY_BEFORE} 11:59:59 PM ..PLEASE WAIT UNTIL FINISHED"
		LOGS=(`find ${4} -type f -newermt "${1}" ! -newermt "${2}" -name "*execution_*" -exec grep -l "${GREP}" {} \;`)
		echo "EXECUTION|START_DATE|START_TIME|END_DATE|END_TIME|JOB_NAME|FULL_JOB_NAME|LOG_FILE" > ${FINAL_FILE}
		
		for FILE in ${LOGS[@]}; do
			NAME=`cat ${FILE} | grep "TalendJob:" | head -n1 | cut -d "-" -f 2 | cut -d ":" -f 2`
			START_DATE=`head -n1 ${FILE} | cut -d " " -f6`
			START_TIME=`head -n1 ${FILE} | cut -d " " -f7`
			FULL_JOB_NAME=`head -n2 ${FILE} | tail -n1 | cut -d " " -f3`
			G=`grep "WITH ERROR" ${FILE}`
			RES=$? 
			if [[ ${FULL_JOB_NAME} == *${PATTERN}* ]]; then
				if [[ ${RES} == 0 ]]; then
					END_DATE=`grep ENDED ${FILE} | cut -d " " -f8`
					END_TIME=`grep ENDED ${FILE} | cut -d " " -f9`
					((ERR++))
					echo "EXECUTION: ERROR ${SEP} START DATE: ${START_DATE} ${SEP} START TIME: ${START_TIME} ${SEP} END DATE: ${END_DATE} ${SEP} END TIME: ${END_TIME} ${SEP} JOB NAME: ${NAME} ${SEP} FULL JOB NAME: ${FULL_JOB_NAME} ${SEP} LOG 0: ${FILE} " >> ${FINAL_FILE}
				else
					END_DATE=`grep ENDED ${FILE} | cut -d " " -f7`
					END_TIME=`grep ENDED ${FILE} | cut -d " " -f8`
					((CORR++))
					echo "EXECUTION: SUCCESS ${SEP} START DATE: ${START_DATE} ${SEP} START TIME: ${START_TIME} ${SEP} END DATE: ${END_DATE} ${SEP} END TIME: ${END_TIME} ${SEP} JOB NAME: ${NAME} ${SEP} FULL JOB NAME: ${FULL_JOB_NAME} ${SEP} LOG FILE: ${FILE} " >> ${FINAL_FILE}
				fi
			fi
		done
	S=`sort -k3,7 -k7 ${FINAL_FILE}`
	
	TOT=$((${ERR}+${CORR}))
	FAILURE_RATE=$(echo 100*${ERR}/${TOT} | bc -l)
	SUCCESS_RATE=$(echo 100*${CORR}/${TOT} | bc -l)

	echo -e "STATS ${PATTERN}:" >> ${FINAL_FILE}
	echo -e " - TOTAL JOBS FOUND: ${TOT} - FAILED JOBS: ${ERR} - SUCCEEDED JOBS: ${CORR} - FAILURE RATE: ${FAILURE_RATE}% - SUCCESS RATE: ${SUCCESS_RATE}%" >> ${FINAL_FILE}

	if [[ ${MAIL} == "Y" ]] || [[ ${MAIL} == "y" ]]; then
		echo "SENDING EMAIL TO ${RECIPIENTS}"
		MAIL=`echo "Please find attached the talend failures for the time window ${DATE} to ${DAY_BEFORE}" | mutt -s "TALEND JOB FAILURES: ${DATE} - ${DAY_BEFORE}" -a ${FINAL_FILE} ${RECIPIENTS}`
	else
		echo "NOT SENDING EMAIL TO ${RECIPIENTS} AS THE EMAIL FLAG WAS NOT SPECIFIED AS Y"
	fi
}

#@Recursive 
iterate()
{
	D1=$(date -d ${1} +"%Y%m%d")
	D2=`date -d "${D1} +7 days" +%Y-%m-%d`
	DATE2FORM=$(date -d ${D2} +"%Y%m%d")
	if [[ ${DATE2FORM} -gt ${TODAYFORM} ]]; then
		echo "FINISHED."
	else
		failures_check ${D1} ${D2} ${PATTERN} ${PROD_LOG_FOLDER} ${MAIL} 
		IT=`$(iterate $[DATE2FORM])`
	fi
}

iterate ${DATE}



minus()
{
        echo ${1}
        if [[ ${1} -le 0 ]]; then
			echo "FINISHED"
        else
			VALUE=$((${1}-1))
			V=$(minus $[VALUE])
			echo -e "${V}\n"
        fi
}


