#!/bin/bash
#Example impala_conn.sh "select count(*) from stg.reading;"

QUERY=${1}

conn(){
impala-shell -B -o output.csv --output_delimiter=',' -q ${QUERY}
}

conn
