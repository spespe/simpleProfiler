#!/bin/bash
HDFS_PATH=${1}
PATTERN=${2}
RECIPIENTS=${3}

usage(){
        echo "USAGE: java -jar script.jar [HDFS MAIN FOLDER CONTAINING ALL THE FILES] [PATTERN]"
        echo "EXAMPLE: java -jar script.jar /data/landing/processing/der_cpr_2018_7/ 30470064374"
        exit 1
}

if [[ $# -lt 2 ]]; then
        usage
fi

FIND=(`hadoop fs -ls ${HDFS_PATH}/* | awk '{print $8}'`)
RES=$?

if [[ ${RES} != 0 ]]; then
        echo "Error finding the files. Please check the hdfs path and the pattern passed."
        usage
fi

for FILE in ${FIND[@]}; do
GREP=`hadoop fs -text $FILE | grep ${PATTERN}`
RES=$?
if [[ ${RES} != 1 ]]; then
        echo "PATTERN FOUND IN FILE ${FILE}"
fi
done

if [[ ! -z ${RECIPIENTS} ]]; then
        MAIL=`echo "File in HDFS LOCATION ${HDFS_PATH} containing the pattern ${PATTERN}: ${FILE}" | mail -s "FILE FOUND IN HDFS FOR PATTERN ${PATTERN}: ${FILE}" ${RECIPIENTS}`
fi


