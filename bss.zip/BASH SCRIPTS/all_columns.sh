#!/bin/bash
##CREATED BY: PIETRO SPERI
##CREATION DATE: 07/19/2018
##CONTACT EMAIL: pietro.speri@sce.com - pietro.speri@infosys.com
##VERSION 0.1
##USAGE: ./all_columns.sh [file]     ##-> THE FILE SHOULD CONTAINS THE LIST OF ALL THE DATABASES YOU WANT TO CHECK IN HIVE

INVENTORY_LOG=inventory.txt

FILE=${1}

if [[ $# -eq 0 ]]; then
	echo "YOU HAVE TO PASS AT LEAST ONE ARGUMENT [FILE WITH THE LIST OF DATABASES]"
	echo "USAGE: sh ${0} [ARG: DATABASES LIST FILE]"
	exit 1
fi

if [[ -z ${FILE} ]]; then
	echo "THE DATABASE LIST FILE DOES NOT EXIST."
	exit 1
fi

ALL_COLS=all_columns.txt
LOGINFO=${0}_INFO.log

if [[ -f ${ALL_COLS} ]]; then
	rm -f ${ALL_COLS}
	rm -f ${LOGINFO}
fi

LIST=(`cat ${FILE}`)

echo "PLEASE WAIT, THE SCRIPT IS SCANNING ALL THE DATABASES IN THE LIST PASSED [${1}]"

for DATABASE in ${LIST[@]}; do
	echo "CHECKING THE DATABASE ${DATABASE}"
	OPTARGS="use ${DATABASE}; show tables;"
	TABLES=(`hive -S -e "${OPTARGS}" 2>/dev/null`)
	CHECK=$?
	if [[ ${CHECK} != 0 ]]; then
		echo "DATABASE ${DATABASE} NOT A VALID DATABASE"
		FINAL+=("${DATABASE} NOT VALID")
	fi
	
	SIZE=${#TABLES[@]}
	echo "[DATABASE: ${DATABASE}] [TABLES COUNT: ${SIZE}]" | tee -a ${LOGINFO}
	if [[ -z ${SIZE} ]] || [[ ${SIZE} -eq 0 ]]; then
		echo "[${DATABASE}] [${SIZE}] [HIVE TABLES NOT FOUND]"
	fi
	
	for TABLE in ${TABLES[@]}; do
		OPTARGS="desc ${DATABASE}.${TABLE}"
		echo "PARAMETER [DESC COLUMNS(HIVE)] [${OPTARGS}]"
		HIVE=`hive -S -e "${OPTARGS}" >${INVENTORY_LOG} 2>/dev/null`
		
		G=`cat ${INVENTORY_LOG} | egrep "^#"`
		CHECK=$?
		if [[ ${CHECK} != 0 ]]; then
			COLUMNS=(`cat ${INVENTORY_LOG} | awk '{print $1 "|" $2}'`)
		else
			PARTITIONS=(`cat ${INVENTORY_LOG} | grep -A100 "^# Partition" | tail -n -1 | awk '{print $1}'`)
			echo "partitions: ${PARTITIONS[@]}" | tee -a ${LOGINFO}
			COLUMNS=(`cat ${INVENTORY_LOG} | grep -EB1000 "^# Partition" | grep -Ev "#|^/s" | awk '{print $1 "|" $2}' | head -n -1`)
		fi
		
		SIZE=${#COLUMNS[@]}
		echo "COLUMNS COUNT [${TABLE}]: ${SIZE}" | tee -a ${LOGINFO}
		
		for COLUMN in ${COLUMNS[@]}; do
			if [[ ${PARTITIONS[@]} =~ ${COLUMN}  ]]; then
				echo "${DATABASE}|${TABLE}|${COLUMN}|[PARTITION FIELD]" >> ${ALL_COLS}
			else
				echo "${DATABASE}|${TABLE}|${COLUMN}" >> ${ALL_COLS}
			fi
		done

	done
	
done


rm -f ${INVENTORY_LOG}

echo "FINISHED. PLEASE CHECK THE FILE ${ALL_COLS}"
