#!/bin/bash
##CREATED BY: PIETRO SPERI
##CREATION DATE: 10/10/2018
##CONTACT EMAIL: pietro.speri@sce.com - pietro.speri@infosys.com
##VERSION 0.1
##USAGE EXAMPLE: ksh ${0} [PATTERN] ESPI [DATE1] 2018-10-10 [DATE2] 2018-10-21 [LOG FOLDER] /PATH/TO/LOGS

GREP="^### Job ENDED"
PATTERN=${1}
ERR=0
CORR=0
SEP="|"
DATE=${2}
DATE2=${3}
PROD_LOG_FOLDER=${4}
FINAL_FILE=".PERCENTAGE_${PATTERN}_${DATE}_${DATE2}"
TODAY=`date "+%Y-%m-%d"`

if [[ $# -lt 4 ]]; then
	echo "THE SCRIPT NEEDS AT LEAST 4 ARGUMENTS."
	echo "EXAMPLE: ksh ${0} [PATTERN] ESPI [DATE1] 2018-10-10 [DATE2] 2018-10-21 [LOG FOLDER] /PATH/TO/LOGS"
    exit 1
fi

if [[ ! -d ${4} ]]; then
    echo "THE SPECIFIED FOLDER [${4}] DOES NOT EXIST."
    exit 1
fi

CHECK=`date "+%Y-%m-%d" -d "${DATE}" > /dev/null  2>&1`
RES=$?
CHECK2=`date "+%Y-%m-%d" -d "${DATE2}" > /dev/null  2>&1`
RES2=$?

DAY_BEFORE=`date -d "${DATE2} -1 days" +%Y-%m-%d`

TODAYFORM=$(date -d ${TODAY} +"%Y%m%d")
DATE1FORM=$(date -d ${DATE} +"%Y%m%d")
DATE2FORM=$(date -d ${DATE2} +"%Y%m%d")

if [[ ${RES} != 0 ]] || [[ ${RES2} != 0 ]] || [[ ${#DATE} != 10 ]] || [[ ${#DATE2} != 10 ]] || [[ ! ${DATE} =~ "-" ]] || [[ ! ${DATE2} =~ "-" ]] || [[ ${DATE1FORM} -ge ${DATE2FORM} ]] || [[ ${DATE1FORM} -ge ${TODAYFORM} ]] || [[ ${DATE2FORM} -gt ${TODAYFORM} ]]; then
        echo "THE DATES PASSED ARE NOT IN THE CORRECT FORMAT. PLEASE PROVIDE THE DATE IN THE FORMAT YYYY-MM-DD. THE SECOND DATE HAS TO BE BIGGER THAN THE FIRST ONE. ALSO, THE MAXIMUM DATE AVAILABLE IS TODAY'S DATE (EXCLUDED FROM THE COMPUTATION)."
        exit 1
fi

if [[ -f ${FINAL_FILE} ]]; then
        rm -f ${FINAL_FILE}
fi

echo "EXECUTION|START_DATE|START_TIME|END_DATE|END_TIME|JOB_NAME|FULL_JOB_NAME|LOG_FILE" > ${FINAL_FILE}

calc(){
	NAME=`cat ${0} | grep "TalendJob:" | head -n1 | cut -d "-" -f 2 | cut -d ":" -f 2`
    START_DATE=`head -n1 ${0} | cut -d " " -f6`
    START_TIME=`head -n1 ${0} | cut -d " " -f7`
	FULL_JOB_NAME=`head -n2 ${0} | tail -n1 | cut -d " " -f3`
	G=`tail -n1 ${0} | grep ERROR`
	RES=$? 
	if [[ ${FULL_JOB_NAME} == *${PATTERN}* ]]; then
		if [[ ${RES} == 0 ]]; then
			END_DATE=`grep ENDED ${0} | cut -d " " -f8`
			END_TIME=`grep ENDED ${0} | cut -d " " -f9`
			((ERR++))
			echo "EXECUTION: ERROR ${SEP} START DATE: ${START_DATE} ${SEP} START TIME: ${START_TIME} ${SEP} END DATE: ${END_DATE} ${SEP} END TIME: ${END_TIME} ${SEP} JOB NAME: ${NAME} ${SEP} FULL JOB NAME: ${FULL_JOB_NAME} ${SEP} LOG 0: ${0} " >> ${FINAL_FILE}
		else
			END_DATE=`grep ENDED ${0} | cut -d " " -f7`
			END_TIME=`grep ENDED ${0} | cut -d " " -f8`
			((CORR++))
			echo "EXECUTION: SUCCESS ${SEP} START DATE: ${START_DATE} ${SEP} START TIME: ${START_TIME} ${SEP} END DATE: ${END_DATE} ${SEP} END TIME: ${END_TIME} ${SEP} JOB NAME: ${NAME} ${SEP} FULL JOB NAME: ${FULL_JOB_NAME} ${SEP} LOG 0: ${0} " >> ${FINAL_FILE}
		fi
	fi
}

echo "FINDING LOGS FOR JOBS ENDED BETWEEN ${DATE} 00:00:00 AM AND ${DAY_BEFORE} 11:59:59 PM ..PLEASE WAIT UNTIL FINISHED"

export -f calc

LOGS=(`find /sceapps/binaries/Talend/Administrator/executionLogs/ -type f -newermt "${DATE}" ! -newermt "${DATE2}" -name "*execution_*" -exec grep -l "${GREP}" {} \; -exec ksh -c "$(typeset -f calc)"'calc' {} \;`)

TOT=$((${ERR}+${CORR}))
FAILURE_RATE=$(echo 100*${ERR}/${TOT} | bc -l)
SUCCESS_RATE=$(echo 100*${CORR}/${TOT} | bc -l)

echo -e "STATS - TOTAL JOBS FOUND: ${TOT} - JOBS FAILED:${ERR} - JOBS SUCCEEDED:${CORR} - FAILURE RATE: ${FAILURE_RATE}% - SUCCESS RATE: ${SUCCESS_RATE}%" >> ${FINAL_FILE}

echo "FINISHED."
