#!/bin/bash
#CREATED BY PIETRO SPERI: pietro.speri@sce.com - pietro.speri@infosys.com
#CREATION DATE: 01-25-2019
#MODIFIED ON: 
# 01-26-2019 - Added new conn() method.
# 01-26-2019 - Added log file.
#USAGE: sh [script.sh] [date_list.txt]

#PARAMS
QUERY1=query1.hql
QUERY2=query2.hql
SSH_USER=bda_edm
SSH_SERVER=iyxvpbda01
DATES=${1}
LIST=`cat ${DATES}`
LOG_FILE=${0}.log
SSH_FOLDER_MAIN=/sourcefiles/WEATHER/RA
HDFS_FOLDER=/data/prod_tmp
PROJECT_HDFS=GridX_Usage_Catch_Up_tmp
FOLDER_BASE_NAME=Catchup_
BASE_NAME=gridx_SCE_interval_1000_1_
BASE_EXTENSION=000000.txt

conn(){
ssh ${1}@${2} << EOF
  hadoop fs -get ${HDFS_FOLDER}/${PROJECT_HDFS}/ ${SSH_FOLDER_MAIN}/${FOLDER_BASE_NAME}${3}
  mkdir ${SSH_FOLDER_MAIN}/${FOLDER_BASE_NAME}${3}/${PROJECT_HDFS}
  mv ${SSH_FOLDER_MAIN}/${FOLDER_BASE_NAME}${3}/0* ${SSH_FOLDER_MAIN}/${FOLDER_BASE_NAME}${3}/${PROJECT_HDFS}
  cd ${SSH_FOLDER_MAIN}/${FOLDER_BASE_NAME}${3}/${PROJECT_HDFS}
  cat 0* >> ${BASE_NAME}${3}${BASE_EXTENSION}
  rm 0*
  sed  -i '1i Serv_Pnt_Id|Rdng_Meas|Rdng_Dttm|Channel|Time_Zone|Interval_Frequency' ${BASE_NAME}${3}${BASE_EXTENSION}
  wc \-l ${BASE_NAME}${3}${BASE_EXTENSION} >> linesCount.txt
  gzip ${BASE_NAME}${3}${BASE_EXTENSION}
  md5sum ${BASE_NAME}${3}${BASE_EXTENSION}.gz >> linesCount.txt
  exit
EOF
}

echo -e "RUNNING ${0} ON FILE ${DATES}" > ${LOG_FILE}

for DATE in ${LIST[@]}; do
	echo -e "RUNNING QUERIES FOR THE DATE ${DATE}" | tee -a ${LOG_FILE}
	DAY_BEFORE=`date -d "${DATE} -1 days" +%Y-%m-%d`
	DAY_AFTER=`date -d "${DATE} +1 days" +%Y-%m-%d`
	QUERY1=`hive -f ${QUERY1} -hivevar DATE_BEFORE_VAR=${DAY_BEFORE}`
	QUERY2=`hive -f ${QUERY2} -hivevar DATE_BEFORE_VAR=${DAY_BEFORE} -hivevar DATE_AFTER_VAR=${DAY_AFTER} -hivevar DATE_VAR=${DATE}`
	RES=$?
	if [[ "${RES}" != "0" ]]; then
		echo -e "THE SCRIPT FAILED RUNNING THE QUERIES FOR THE DATE ${DATE}" | tee -a ${LOG_FILE}
		exit 1
	fi
	echo -e "RUNNING SSH CONNECTION. IF FAILING IT WILL END AUTOMATICALLY. PLEASE WAIT.." | tee -a ${LOG_FILE}
	conn ${SSH_USER} ${SSH_SERVER} ${DATE//-/}
	RES2=$?
	if [[ "${RES2}" != "0" ]]; then
		echo -e "THE SCRIPT FAILED RUNNING THE SSH COMMANDS ON THE ${SSH_SERVER} MACHINE FOR THE DATE ${DATE}. PLEASE VERIFY THE STATUS OF THE DATA ON THE ${SSH_SERVER} MACHINE." | tee -a ${LOG_FILE}
		exit 1
	fi
	echo -e "RUN COMPLETED SUCCESSFULLY FOR DATE ${DATE}. PLEASE CHECK ON THE ${SSH_SERVER} MACHINE." | tee -a ${LOG_FILE}
done
