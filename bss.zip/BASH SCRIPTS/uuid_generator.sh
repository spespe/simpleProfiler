#!/bin/bash
##CREATED BY: PIETRO SPERI
##CREATION DATE: 10/18/2018
##CONTACT EMAIL: pietro.speri@sce.com - pietro.speri@infosys.com
##VERSION 0.1
#Script called from Talend
#Example: ./uuid.sh core te_featr /home1/sperip/uuid_output 

DATABASE=${1}
TABLE_NAME=${2}
LOCAL_DIRECTORY=${3}
HDFS_DIRECTORY=/tmp/${TABLE_NAME}_output
DATETIME=`date "+%Y-%m-%d %H:%M:%S"`
LOG_FILE=./${0}.error
JAR_FILE=UUID_generator.jar
HDFS_LOCATION=/tmp/
ENGINE="spark"
JOB_NAME="UUID_GENERATION"
OPT="INSERT OVERWRITE DIRECTORY '${HDFS_DIRECTORY}' ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE"
QUERY="SELECT uuid(''),* FROM ${DATABASE}.${TABLE_NAME};"

usage(){
	echo -e "ARGUMENTS PASSED: DATABASE[${1}] TABLE_NAME[${2}] LOCAL_DIRECTORY[${3}]"
	echo -e "USAGE: sh ${0} [DATABASE] [TABLE_NAME] [LOCAL DIRECTORY]. \nEXAMPLE: ./uuid.sh core te_featr /home1/user/uuid_result"
}

if [[ ${#} != 3 ]]; then
	usage
	exit 1
fi

CHECK=`hadoop fs -test -e ${HDFS_LOCATION}${JAR_FILE}`
C=$?

if [[ ${C} != 0 ]]; then
	echo "THE JAR FILE IS NOT PRESENT IN THE HDFS LOCATION ${HDFS_LOCATION}... MOVING IT AGAIN.."
	MOVE=`hadoop fs -put ${JAR_FILE} ${HDFS_LOCATION}`
	M=$?
	if [[ ${M} != 0 ]]; then
		echo "[${DATETIME}] - FAILURE - [ NOT ABLE TO MOVE THE JAR FILE ${JAR_FILE} TO THE HDFS LOCATION ${HDFS_LOCATION} ]" | tee -a ${LOG_FILE}
		exit 1
	fi
	
fi

QUERY=`hive -S -e "set hive.execution.engine=${ENGINE}; set mapreduce.job.name=${JOB_NAME}; ${OPT} ${QUERY}"`
Q=$?

if [[ ${Q} != 0 ]]; then
	echo -e "[${DATETIME}] - FAILURE: PLEASE CHECK THE ARGUMENTS PROVIDED - \n[QUERY: ${QUERY}]" | tee -a ${LOG_FILE}
	usage
fi

MOVE=`hadoop fs -text ${HDFS_DIRECTORY}/* > ${LOCAL_DIRECTORY}/output.txt`
M=$?

if [[ ${M} != 0 ]]; then
	echo -e "[MOVE FAILED] - FAILED TO MOVE THE DATA IN ONE UNIQUE FILE UNDER THE DIRECTORY ${LOCAL_DIRECTORY}" | tee -a ${LOG_FILE}
	exit 1
fi

echo "THE SCRIPT FINISHED SUCCESSFULLY"

