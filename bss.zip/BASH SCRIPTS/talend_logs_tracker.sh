#!/bin/bash
##CREATED BY: PIETRO SPERI
##CREATION DATE: 10/10/2018
##CONTACT EMAIL: pietro.speri@sce.com - pietro.speri@infosys.com
##VERSION 0.1
##USAGE: ./talend_logs_tracker.sh [date1] [date2]

PROD_LOG_FOLDER=/sceapps/binaries/Talend/Administrator/executionLogs
GREP="^### Job ENDED WITH ERROR"
SEP="|"
DATE=${1}
DATE2=${2}

CHECK=`date "+%Y-%m-%d" -d "${DATE}" > /dev/null  2>&1`
RES=$?
CHECK2=`date "+%Y-%m-%d" -d "${DATE2}" > /dev/null  2>&1`
RES2=$?

DAY_BEFORE=`date -d "${DATE2} -1 days" +%Y-%m-%d`

if [[ ${RES} != 0 ]] || [[ ${RES2} != 0 ]] || [[ ${#DATE} != 10 ]] || [[ ${#DATE2} != 10 ]] || [[ ! ${DATE} =~ "-" ]] || [[ ! ${DATE2} =~ "-" ]] || [[ ! ${DATE} -ge ${DATE2} ]]; then
	echo "THE DATES PASSED ARE NOT IN THE CORRECT FORMAT. PLEASE PROVIDE THE DATE IN THE FORMAT YYYY-MM-DD. THE SECOND DATE HAS TO BE BIGGER THAN THE FIRST ONE."
	echo "USAGE EXAMPLE: ${0} 2018-08-29 2018-09-21"
	echo "THIS SCRIPT WILL FIND ALL THE JOBS ENDED BETWEEN THE FIRST DATE AND THE SECOND ONE, LAST DAY EXCLUDED."
	exit 1
fi

TMP_FILE=".tmp_TALEND_FAILURES_${DATE}_${DATE2}.txt"
FINAL_FILE="TALEND_FAILURES_${DATE}_${DAY_BEFORE}.txt"

if [[ -f ${FINAL_FILE} ]]; then
	rm -f ${FINAL_FILE}
fi

echo "FINDING LOGS FOR JOBS ENDED BETWEEN ${DATE} 00:00:00 AM AND ${DAY_BEFORE} 11:59:59 PM ..PLEASE WAIT UNTIL FINISHED"
LOGS=(`find ${PROD_LOG_FOLDER} -type f -newermt "${DATE}" ! -newermt "${DATE2}" -exec grep -l "${GREP}" {} \; `)

echo "START_DATE|START_TIME|END_DATE|END_TIME|JOB_NAME|FULL_JOB_NAME|LOG_FILE" > ${TMP_FILE}

for FILE in ${LOGS[@]}; do
	NAME=`cat ${FILE} | grep "TalendJob:" | head -n1 | cut -d "-" -f 2 | cut -d ":" -f 2` 
	START_DATE=`grep "### JOB STARTED" ${FILE} | awk '{print $8}'`
	START_TIME=`grep "### JOB STARTED" ${FILE} | awk '{print $9}'`
	END_DATE=`grep -o -P -i 'Job ENDED WITH ERROR at.{0,20}' ${FILE} | awk '{print $6}'`
	END_TIME=`grep -o -P -i 'Job ENDED WITH ERROR at.{0,20}' ${FILE} | awk '{print $7}'`
	FULL_JOB_NAME=`grep "### JOB STARTED" ${FILE} | awk '{print $14}'`
	echo "${FULL_JOB_NAME}"
	echo "PROCESSING LOG: ${FILE}"
	echo "START DATE: ${START_DATE} ${SEP} START TIME: ${START_TIME} ${SEP} END DATE: ${END_DATE} ${SEP} END TIME: ${END_TIME} ${SEP} JOB NAME: ${NAME} ${SEP} FULL JOB NAME: ${FULL_JOB_NAME} ${SEP} LOG FILE: ${FILE} " >> ${TMP_FILE} 
done

S=`sort -k3,7 -k7 ${TMP_FILE} > ${FINAL_FILE}`
RM=`rm ${TMP_FILE}`

echo "FINISHED."
