#!/bin/bash

READING=(`hadoop fs -ls /data/landing/archive/reading/processed/*/READING.D2* | grep "/20181231" | awk '{print $8}'`)

NUM=0
for el in ${READING[@]}; do
C=`hadoop fs -text ${el} | wc -l`
NUM=$(( ${NUM} + ${C} ))
echo "FILE:${el} - ROW_COUNT:${C} - TOTAL ROWCOUNT: ${NUM}" >> mtr_rdng_processed_check.txt
done

REGISTER=(`hadoop fs -ls /data/landing/archive/reading/processed/*/REGISTERREADING.D2* | grep "/20181231" | awk '{print $8}'`)

NUM=0
for el in ${REGISTER[@]}; do
C=`hadoop fs -text ${el} | wc -l`
NUM=$(( ${NUM} + ${C} ))
echo "FILE:${el} - ROW_COUNT:${C} - TOTAL ROWCOUNT: ${NUM}" >> mtr_rdng_processed_check.txt
done

