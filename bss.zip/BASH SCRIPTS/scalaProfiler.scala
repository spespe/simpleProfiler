spark-shell --driver-memory 16G --num-executors 32 --executor-cores 16 --executor-memory 16G
spark-submit --driver-memory 32G --num-executors 64 --executor-cores 16 --executor-memory 16G --master yarn-client --class spark.profiling profiling.jar "stg" "readinggroupspc" "spcnodeid" "N"
PROFILER1=`spark-submit --driver-memory 32G --num-executors 64 --executor-cores 16 --executor-memory 16G --master yarn-client --class spark.profiling profiling.jar "stg" "readinggroupspc" "spcnodeid" "N"`
spark-submit --driver-memory 32G --num-executors 64 --executor-cores 16 --executor-memory 16G sparkProfiler.py ${DB} ${TABLE} ${COLUMN}
profiler("etl")("eeat_billing_temp")("serv_pnt_id")

import java.util.Date
import java.util.concurrent.TimeUnit
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkContext
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.SQLContext

Logger.getLogger("akka").setLevel(Level.OFF)
Logger.getLogger("org").setLevel(Level.OFF)
	
def profiler(db: => String)(table: => String)(col: => String)={
      val sep="|"
	  println("creating RDD")
      val rdd=sqlContext.table(db+"."+table).select(col).rdd.persist(StorageLevel.MEMORY_AND_DISK)
	  println("PERFORMING COUNT")
	  val count=rdd.count
	  println("Performing distinct")
      val distinctCount=rdd.distinct.count
      val isDistinct=if(count==distinctCount)"TRUE" else "FALSE"
      val blanks=rdd.filter(x=>x.mkString.isEmpty).count
      val withBlanks=if(blanks==0)"FALSE" else "TRUE"
      val hasNull=rdd.filter(x=>x!=null).isEmpty.toString.toUpperCase
      val maxLength=rdd.reduce((a,b)=>if(a.mkString.length>b.mkString.length) a else b).mkString.length
      val minLength=rdd.reduce((a,b)=>if(a.mkString.length<b.mkString.length) a else b).mkString.length
      rdd.unpersist()
      println(db+sep+table+sep+col+sep+isDistinct+sep+withBlanks+sep+hasNull+sep+maxLength+sep+minLength)
    }
	
PROFILER1=`spark-submit --driver-memory 32G --num-executors 64 --executor-cores 16 --executor-memory 16G --master yarn-client --class spark.profiling profiling2.jar "etl" "espi_ofln_bill_per_temp" "ofln_tp_domain" "Y"`
EMPTY
profiler("etl")("espi_ofln_bill_per_temp")("ofln_tp_domain")

profiler("lndg_processing")("te_exporthistory")("exporthistorykey")
profiler("stg")("exporthistory")("exporthistorykey")
profiler("lndg_processing")("te_reading")("nodeid")
profiler("lndg_processing")("te_reading")("readinggroupalternatekey")
profiler("lndg_processing")("te_readinggroupspc")("spcnodeid")
profiler("lndg_processing")("te_readinggroupspc")("readinggroupalternatekey")
profiler("lndg_processing")("te_readinggroupspc")("starttime")
profiler("lndg_processing")("te_readinggroupspc")("tran_time_utc")
profiler("stg")("readinggroupspc")("spcnodeid")
profiler("stg")("readinggroupspc")("readinggroupalternatekey")

//ab+=profiler("stg")("reading")("nodeid") ==> to check
//ab+=profiler("stg")("reading")("readinggroupalternatekey") ==> to check

ab+=profiler("stg")("readinggroupspc")("starttime")
ab+=profiler("stg")("readinggroupspc")("tran_time_utc")
ab+=profiler("lndg_processing")("te_readingreadingstatusfull")("statusid")
ab+=profiler("lndg_processing")("te_readingreadingstatusfull")("source_commit_seq")
ab+=profiler("stg")("readingreadingstatusfull")("statusid")
ab+=profiler("stg")("readingreadingstatusfull")("source_commit_seq")
ab+=profiler("lndg_processing")("te_flatconfigphysical")("servicepointnodekey")
ab+=profiler("lndg_processing")("te_flatconfigphysical")("channelnumber")
ab+=profiler("lndg_processing")("te_flatconfigphysical")("effectivestartdate")
ab+=profiler("stg")("flatconfigphysical")("servicepointnodekey")
ab+=profiler("stg")("flatconfigphysical")("channelnumber")
ab+=profiler("stg")("flatconfigphysical")("effectivestartdate")
ab+=profiler("lndg_processing")("te_readinggroup")("readinggroupkey")
ab+=profiler("stg")("readinggroup")("readinggroupkey")
ab+=profiler("etl")("eeat_usg_int_rdng_dt")("rdng_dt")


ab+=profiler("stg")("reading")("process_dt")

ab.foreach(println)

