# ---------------------------------------------------------------------------------------------------------------------------------------------------#
#!/bin/sh
# Created Date
# Created By
# Description : This Shellscript.
# ---------------------------------------------------------------------------------------------------------------------------------------------------#

#******************************************************************************#
# Setting Parameters
#******************************************************************************#
taskName=$1
PARAM1=$2
PARAM2=$3
PARAM3=$4
PARAM4=$5
PARAM5=$6

currUser=`whoami`
currDate=$(date +"%d-%m-%y")
currTime=$(date +"%H:%M:%S")
tstamp=$(date +"%d%m%y%H%M")

export LOGFILE=/sceapps/data/scripts/logs/${taskName}_${tstamp}.log
. /sceapps/data/scripts/bin/property_edm.dat

logmsg() {
		message=$1
        echo `date '+%D %T'` "|" $message
        echo `date '+%D %T'` "|" $message >>$LOGFILE
}

get_log_file() {

log_status=`sh MetaServletCaller.sh --tac-url ${tac_url}  --json-params '{"actionName":"taskLog","authPass":"'${authPass}'","authUser":"'${authUser}'","lastExecution":"true","taskId":'"${task_id}"'}'`
logmsg "$log_status"
}

#******************************************************************************#
# Main Program
#******************************************************************************#
cd $tac_path
logmsg "Script Started: Task ID Retrieval Process Started"
logmsg "Get Task ID"

task_id_tmp=`sh MetaServletCaller.sh --tac-url ${tac_url} --json-params '{"actionName":"getTaskIdByName","authPass":"'${authPass}'","authUser":"'${authUser}'","taskName":"'${taskName}'"}'`

task_id=`echo ${task_id_tmp} | awk -v FS=':' '{print $6}'| tr -dc '[0-9]' `

if [ ! -z "$task_id" ]; then
	logmsg "Task_ID Retrieved: Successfully. TASK ID : $task_id "
else
	logmsg "Task_ID Retrieved: Failed"
	exit 1
fi

logmsg "Job Started"
logmsg "sh MetaServletCaller.sh --tac-url ${tac_url} --json-params '{"actionName":"runTask","authPass":'"$authPass"',"authUser":'"$authUser"',"mode":"synchronous","taskId":"$task_id","context":{"P_param1":'"$PARAM1"',"P_param2":'"$PARAM2"',"P_param3":'"$PARAM3"',"P_param4":'"$PARAM4"',"P_param5":'"$PARAM5"'}}'"

logmsg "PARAM1: ${PARAM1}"
logmsg "PARAM2: ${PARAM2}"
logmsg "PARAM3: ${PARAM3}"
logmsg "PARAM4: ${PARAM4}"
logmsg "PARAM5: ${PARAM5}"

exit_cd=`sh MetaServletCaller.sh --tac-url http://ayxvqtln01:8080/org.talend.administrator-6.2.1 --json-params "{actionName:runTask,authPass:'${authPass}',authUser:'${authUser}',mode:synchronous,taskId:'${task_id}',context:{P_param1:'${PARAM1}',P_param2:'${PARAM2}',P_param3:'${PARAM3}',P_param4:'${PARAM4}',P_param5:'${PARAM5}'}}"`

exit_code=`echo ${exit_cd} | awk -v FS=, '{print $8}'| tr -d "'" | awk -v FS=':' '{print $2}'`
errStatus=`echo ${exit_cd} | awk -v FS=, '{print $1}'| tr -d "\'" | awk -v FS=':' '{print $2}'`

logmsg "exit_cd : $exit_cd"
logmsg "exit_code : $exit_code"
logmsg "exit_code : $exit_code"
logmsg "errStatus : $errStatus"

#CHECKING ERROR STATUS
if [[ "${errStatus}" =~ "NO_ERROR" ]]; then
	logmsg "Job completed Successfully: Please check the log for more details"
	get_log_file
elif [[ "${errStatus}" =~ "UNEXPECTED_ERROR" ]]; then
	logmsg "Job Failed: Please check the error log for more details. ExitCode: $exit_code :: ErrorStatus: $errStatus"
	get_log_file
	exit 1
else
	logmsg "Job Failed: Please check the error log for more details. ExitCode: $exit_code :: ErrorStatus: $errStatus"
	get_log_file
	exit $exit_code
fi

logmsg "Script End"


