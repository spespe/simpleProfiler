#!/bin/bash +x
TODAY=`date "+%Y-%m-%d"`
TODAYFORM=$(date -d ${TODAY} +"%Y%m%d")

iterate()
{
    D1=$(date -d ${1} +"%Y%m%d")
    D2=`date -d "${D1} +7 days" +%Y-%m-%d`
    DATE2FORM=$(date -d ${D2} +"%Y%m%d")
    if [[ ${DATE2FORM} -gt ${TODAYFORM} ]]; then
     echo "FINISHED."
    else
     echo -e "\n WAITING FOR THE NEXT WEEK \n"
	 sleep 1
     IT=$(iterate $[$DATE2FORM])
     echo ${IT[@]}
    fi
}

iterate "2018-01-01"



#!/bin/bash
TODAY=`date "+%Y-%m-%d"`
TODAYFORM=$(date -d ${TODAY} +"%Y%m%d")

iterate()
{
	D1=$(date -d ${1} +"%Y%m%d")
	D2=`date -d "${D1} +7 days" +%Y-%m-%d`
	DATE2FORM=$(date -d ${D2} +"%Y%m%d")
	if [[ ${DATE2FORM} -gt ${TODAYFORM} ]]; then
		echo "FINISHED."
	else
		echo "WAITING FOR THE NEXT WEEK"
		$(iterate $[DATE2FORM])
	fi
}

iterate 2018-01-01


