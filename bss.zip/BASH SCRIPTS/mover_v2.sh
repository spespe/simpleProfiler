#!/bin/bash
##CREATED BY: PIETRO SPERI
##CREATION DATE: 06/08/2018
##CONTACT EMAIL: pietro.speri@sce.com - pietro.speri@infosys.com
##VERSION 0.1
##USAGE: ./mover.sh [PARAMETER] ("FULL" or "INPUT" or "OUTPUT")
##MODIFICATIONS(if any): 06/10/2018 - Added 'wait' command to wait for the end of the cp command. LINES 46-47
##MODIFICATIONS(if any): 06/11/2018 - Added logcut(), timer() and launcher() methods.

INIT_TIMESTAMP=`date '+%Y-%m-%d %H:%M:%S'`
USER=`whoami`
APP_NAME=$(basename ${0})
APP_DIR=`pwd`
FILES_PATH=/dsprojectsprd/SM_APM_N1_PROD/CSDB
INPUT_FOLDER=${FILES_PATH}/INPUT
OUTPUT_FOLDER=${FILES_PATH}/OUTPUT
LANDING_FOLDER=${FILES_PATH}/LANDING/INPUT
LOGINFO=${APP_NAME}_LOG_INFO
LOGERROR=${APP_NAME}_LOG_ERROR
HOSTNAME=`hostname`
EXTENSION=zip
LIMITROWS=3000
INPUT_COMMAND=MASTER_CSDB_INPUT
OUTPUT_COMMAND=MASTER_CSDB_OUTPUT
OUTPUT_NAME=_Output

usage(){
   echo -e "USAGE: sh ${APP_NAME} <PARAMETER1> [ 'INPUT' OR 'OUTPUT' OR 'FULL' ONLY] \n
   [INPUT] - To launch the jobs only on the INPUT files \n
   [OUTPUT] - To launch the jobs only on the OUTPUT files \n
   [FULL] - To launch the jobs on both INPUT and OUTPUT files respectively."
   exit 1
}

#---------------------------------- PARAMETERS CHECK ------------------------------------#
if [[ $# -eq 1 ]]; then
   PARAMETER1=${1}
   echo "PARAMETER1 = ${PARAMETER1}"
else
	usage
fi
#----------------------------------------------------------------------------------------#

##CHECKING THE FOLDERS
if [[ ! -d ${INPUT_FOLDER} ]] || [[ ! -d ${LANDING_FOLDER} ]] || [[ ! -d ${OUTPUT_FOLDER} ]]; then
	echo "ERROR ENCOUNTERED: THE FOLDER ${INPUT_FOLDER} or ${LANDING_FOLDER} or ${OUTPUT_FOLDER} DOES NOT EXISTS. PLEASE VERIFY AND TRY AGAIN." | tee -a ${LOGERROR}
	exit 1
fi

#LOG CUT
logcut(){
	if [[ -f ${1} ]]; then
		TMP_TAIL=`tail -n ${LIMITROWS} ${1} > ${1}.tmp`
		CHECK=$?
		if [[ ${CHECK} != 0 ]]; then
			echo "ERROR LAUNCHING THE TAIL COMMAND ON THE FILE ${1} [LOGCUT METHOD]" | tee -a ${LOGINFO} ${LOGERROR}
			exit 1
		fi
		MV=`mv ${1}.tmp ${1}`
		CHECK=$?
		if [[ ${CHECK} != 0 ]]; then
			echo "ERROR LAUNCHING THE MV COMMAND ON THE FILE ${1}.tmp [LOGCUT METHOD]" | tee -a ${LOGINFO} ${LOGERROR}
			exit 1
		fi
	fi
}

#TOTAL TIME CHECK
timer(){
	DURATION=${SECONDS}
	echo "THE SCRIPT ${APP_NAME} FINISHED SUCCESSFULLY. [TOTAL TIME TAKEN (HH:mm:SS): $((${DURATION} / 3600))HH:$((${DURATION} / 60 % 60))mm:$((${DURATION} % 60))SS] [USER:${USER}] [HOSTNAME:${HOSTNAME}]" | tee -a ${LOGINFO}
	
}

#LAUNCHER
launcher(){
	FOLDER=$1
	COMMAND=$2
	STR_OUTPUT=$3

	FIND=`find ${FOLDER}/* -prune -type f -name "TransactionLog${STR_OUTPUT}\\.*\\.${EXTENSION}"`
	CHECK=$?
	if [[ ${CHECK} != 0 ]]; then
		echo "ERROR LAUNCHING THE FIND COMMAND - [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${INIT_TIMESTAMP}]" | tee -a ${LOGERROR}
		exit 1
	fi

	echo "STARTING THE SCRIPT ${APP_NAME} - [DIRECTORY: ${APP_DIR}] [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${INIT_TIMESTAMP}]" | tee -a ${LOGINFO}
	#COPYING FILES ONE BY ONE
	for FILE in ${FIND}; do
		START=`date +%s`
		CURRENT_DATE=`date '+%Y-%m-%d %H:%M:%S'`
		LANDING_FILE=${LANDING_FOLDER}/$(basename ${FILE})
		echo "COPYING [FILE: ${FILE}] TO [DESTINATION:${LANDING_FOLDER}] - [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${CURRENT_DATE}]" | tee -a ${LOGINFO}
		CP=`cp -p ${FILE} ${LANDING_FOLDER} &`
		CHECK=$?
		if [[ ${CHECK} != 0 ]]; then
			echo "ERROR COPYING [FILE: ${FILE}] - [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${CURRENT_DATE}]" | tee -a ${LOGERROR}
			exit 1
		fi
		#WAITING FOR THE END OF CP 
		wait $!
		echo "FINISHED COPYING [FILE: ${FILE}] TO [DESTINATION:${LANDING_FOLDER}] - [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${CURRENT_DATE}]" | tee -a ${LOGINFO}
		##RUNNING COMMAND IN THE CURRENT FOLDER
		echo "RUNNING THE SCRIPT csdb_runjob.ksh ON THE FILE ${LANDING_FILE} - [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${CURRENT_DATE}]" | tee -a ${LOGINFO}
		COMM=`/dsprojectsprd/SM_APM_N1_PROD/CSDB/SHL/csdb_runjob.ksh -param pCSDB_Monitor=PROD SM_APM_N1_PROD dsprojectsprd ${COMMAND}`
		CHECK=$?
		if [[ ${CHECK} != 0 ]]; then
			echo "ERROR LAUNCHING THE COMMAND ON THE FILE ${LANDING_FILE} - [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${CURRENT_DATE}]" | tee -a ${LOGERROR}
			exit 1
		fi
		END=`date +%s`
		RUNTIME=$((END-START))
		#FILE_DATE=`echo ${FILE#*.} | cut -d "_" -f1`
		#FILE_YEAR=`echo ${FILE_DATE} | cut -c 0-4`
		#FILE_MONTH=`echo ${FILE_DATE} | cut -c 5-6`
		#FILE_DAY=`echo ${FILE_DATE} | cut -c 7-8`
		#FILE_DATE_FORMATTED="${FILE_YEAR}-${FILE_MONTH}-${FILE_DAY}"
		echo "SUCCESSFULLY PROCESSED THE FILE ${LANDING_FILE} - [DURATION: $(($RUNTIME/60)) MINUTES AND $(($RUNTIME % 60)) SECONDS] [USER:${USER}] [HOSTNAME:${HOSTNAME}] " | tee -a ${LOGINFO}
	done
	
	#unset ${FILE}
}

#START
SECONDS=0

if [[ ${PARAMETER1} = "FULL" ]]; then
	launcher ${INPUT_FOLDER} ${INPUT_COMMAND} 
	launcher ${OUTPUT_FOLDER} ${OUTPUT_COMMAND} ${OUTPUT_NAME}
elif [[ ${PARAMETER1} = "INPUT" ]]; then
	launcher ${INPUT_FOLDER} ${INPUT_COMMAND} 
elif [[ ${PARAMETER1} = "OUTPUT" ]]; then
	launcher ${OUTPUT_FOLDER} ${OUTPUT_COMMAND} ${OUTPUT_NAME}
else
	echo "ERROR LAUNCHING SCRIPT ${APP_NAME} - [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${INIT_TIMESTAMP}]" | tee -a ${LOGERROR}
	usage
	exit 1
fi

#TIMER
timer
#LOG CUTS
logcut ${LOGERROR}
logcut ${LOGINFO}
