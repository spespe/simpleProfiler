#!/bin/bash

TABLES_LIST=${1}
OUTPUT=${0}_result.psv
LIST=`cat ${TABLES_LIST}`
SEP="|"
OPT='--driver-memory 32G --num-executors 64 --executor-cores 16 --executor-memory 16G --master yarn-client'
JAR_FILE='profiling.jar'
CLASS='--class spark.profiling'

echo "DB${SEP}TABLE${SEP}COLUMN${SEP}DISTINCT${SEP}NULLS${SEP}BLANKS${SEP}MAX_LENGTH${SEP}MIN_LENGTH" > ${OUTPUT}
for LINE in ${LIST[@]}; do
	DB=`echo ${LINE} | cut -d ${SEP} -f1`
	TABLE=`echo ${LINE} | cut -d ${SEP} -f2`
	COLUMN=`echo ${LINE} | cut -d ${SEP} -f3`
	echo "[LAUNCHING SPARK PROFILER ON ${DB}.${TABLE} FOR COLUMN ${COLUMN} CACHING]"
	PROFILER1=`spark-submit ${OPT} ${CLASS} ${JAR_FILE} "${DB}" "${TABLE}" "${COLUMN}" "Y"`
	RES1=$?
	if [[ "${RES}" == "0" ]]; then
		echo ${PROFILER1} >> ${OUTPUT}
	else
		echo "[LAUNCHING SPARK PROFILER ON ${DB}.${TABLE} FOR COLUMN ${COLUMN} WITHOUT CACHING]"
		PROFILER2=`spark-submit ${OPT} ${CLASS} ${JAR_FILE} "${DB}" "${TABLE}" "${COLUMN}" "N"`
		RES2=$?
		if [[ "${RES2}" == "0" ]]; then
			echo ${PROFILER2} >> ${OUTPUT}
		else
			echo "${DB}${SEP}${TABLE}${SEP}${COLUMN}${SEP}FAILED${SEP}FAILED${SEP}FAILED${SEP}FAILED${SEP}FAILED" >> ${OUTPUT}
		fi
	fi
done	
