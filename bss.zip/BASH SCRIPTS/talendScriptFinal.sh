#!/bin/bash
##CREATED BY: PIETRO SPERI
##CREATION DATE: 04/12/2018
##CONTACT EMAIL: pietro.speri@sce.com - pietro.speri@infosys.com
##VERSION 0.2
##MODIFICATIONS(if any): 
##PIETRO SPERI 04/17 - Added conn method to publish a list of services using netcat
##PIETRO SPERI 04/17 - Added screen command to open multisession
##PIETRO SPERI 04/18 - Added log_cleaner method

#!/bin/bash +x
TODAY=`date "+%Y-%m-%d"`
TODAYFORM=$(date -d ${TODAY} +"%Y%m%d")

iterate()
{
    D1=$(date -d ${1} +"%Y%m%d")
    D2=`date -d "${D1} +7 days" +%Y-%m-%d`
    DATE2FORM=$(date -d ${D2} +"%Y%m%d")
    if [[ ${DATE2FORM} -gt ${TODAYFORM} ]]; then
     echo "FINISHED."
    else
     echo -e "\n WAITING FOR THE NEXT WEEK \n"
         sleep 1
     IT=$(iterate $[$DATE2FORM])
     echo ${IT[@]}
    fi
}

iterate "2018-01-01"


echo -e "\e[0;33m \n-- USAGE -- \nPOPULATE THE FILE 'jobNames.txt' WITH THE LIST OF JOB NAMES YOU NEED TO PUBLISH ONE FOR EACH LINE, THEN SAVE THE FILE. \nNOW YOU CAN PUBLISH LAUNCHING THE COMMAND: ${0} \e[0m"
sleep 3

DATE=`date +%D| tr '/' '_'`
DIR=$(dirname $(readlink -m $0))
LOG_NAME="TALEND_JOB_PUBLISHER"
LOG_FILE="${DIR}/${LOG_NAME}_${DATE}.log"
USER=`whoami`
HOSTNAME=`hostname`
SERVER="localhost"
PORT_NUMBER="7002"
JOBFILE="${DIR}/jobNames.txt"
SCREEN_NAME="talendServer"
LOG_DAYS=30

if [[ ! -f ${JOBFILE} ]]; then
	echo -e "\e[0;31m ERROR ENCOUNTERED: THE FILE ${JOBFILE} DOES NOT EXISTS. \e[0m" | tee -a ${LOG_FILE}
	exit 1
fi

conn(){
( 
	echo ${SERVER} ${1} 
	sleep 1
	echo -e "\r"
	sleep 1
	echo initRemote http://ayxvqtln01.sce.com:8080/org.talend.administrator-6.2.1 -ul Nishanth.Magham@sce.com -up Talend123
	sleep 1
	echo -e "\r"
	sleep 1
	echo logonProject -pn EDM -ul Nishanth.Magham@sce.com -up Talend123 -br trunk
	sleep 1
	echo -e "\r"
	sleep 1
	echo publishJob ${2} --version 0.1 --artifactId ${2} --publish-version 0.1 ${3} -s --artifact-repository http://iyxvdtln03.sce.com:8081/nexus/content/repositories/snapshots --username admin --password Talend123 --type standalone 
	sleep 1
	echo -e "\r"
	sleep 1
	echo quit
	) | netcat
}

log_cleaner(){
CLEAN=(`find ${DIR} -maxdepth 1 -type f -mtime "+"$LOG_DAYS -name "*${LOG_NAME}*"`)

for LOGS in ${CLEAN}; do
	rm -f ${LOGS}
done

}

SERVER_CHECK=`ps aux | grep ${PORT_NUMBER} | grep startServer | wc -l`
TS=$?
if [[ "${SERVER_CHECK}" == "0" ]]; then
	DATETIME1=`date`
	echo -e "\e[0;32m STARTING TALEND SERVER ON PORT ${PORT_NUMBER} - [USER:${USER}][HOSTNAME:${HOSTNAME}][PORT: ${PORT_NUMBER}][DATETIME:${DATETIME1}] \e[0m" | tee -a ${LOG_FILE}
	TALEND_SERVSTART=`screen -S ${SCREEN_NAME} -dm bash -c  'cd /sceapps/binaries/Talend-6.2.1/cmdline/studio; ./Talend-Studio-linux-gtk-x86 -nosplash -application org.talend.commandline.CommandLine -consoleLog -data commandline-workspace94 startServer -p 7002'`
	TS=$?
	echo "PLEASE WAIT FOR THE TALEND SERVER TO START.."
	sleep 15
fi

if [[ "$TS" != "0" ]]; then
	echo -e "\e[0;31m ERROR ENCOUNTERED WHILE LAUNCHING THE TALEND SERVER. PLEASE CHECK IF THE PORT NUMBER IT IS ALREADY IN USE. - [USER:${USER}][HOSTNAME:${HOSTNAME}][PORT: ${PORT_NUMBER}][DATETIME:${DATETIME1}] \e[0m" | tee -a ${LOG_FILE}
	exit 1
fi

## We can customize much much more than this.. we can also parallelize it to make it faster..
LIST=(`cat ${JOBFILE}`)

for JOB in ${LIST[@]}; do
	DATETIMEFOR=`date`
	echo -e "\e[0;32m PUBLISHING TALEND JOB ${JOB} - [USER:${USER}][HOSTNAME:${HOSTNAME}][DATETIME:${DATETIMEFOR}] \e[0m" | tee -a ${LOG_FILE}
	
	conn ${PORT_NUMBER} ${JOB} #folder optional as 3rd param
	N=$?
	
	if [[ "${N}" != "0" ]]; then
		echo -e "\e[0;31m ERROR ENCOUNTERED WHILE LAUNCHING COMMAND THROUGH NETCAT CONNECTION.  PLEASE CHECK IF THE PORT NUMBER IT IS ALREADY IN USE. ${PORT_NUMBER} [DATETIME:${DATETIMEFOR}] \e[0m" | tee -a ${LOG_FILE}
		echo -e "\e[0;33m YOU CAN VERIFY THE ISSUE ON THE TALEND SERVER USING the 'screen -r command'. [SCREEN NAME: ${SCREEN_NAME}] [DATETIME:${DATETIMEFOR}] \e[0m" | tee -a ${LOG_FILE}
		exit 1
	fi

	echo -e "\e[0;32m JOB ${JOB} SUCCESSFULLY PUBLISHED [DATETIME:${DATETIMEFOR}] \e[0m" | tee -a ${LOG_FILE}
done

echo "stopServer" | netcat ${SERVER} ${PORT_NUMBER}
#CLOSE_SESSION=`screen -X -S ${SCREEN_NAME} quit`

DATETIME=`date`
echo -e "\e[0;33m \nFINISHED! - [USER:${USER}][HOSTNAME:${HOSTNAME}][DATETIME:${DATETIME}] \e[0m" | tee -a ${LOG_FILE}
log_cleaner
