#!/bin/bash

TABLES_LIST=${1}
OUTPUT=${0}_result.psv
LIST=`cat ${TABLES_LIST}`
SEP="|"
PROFILER_PY=sparkProfiler.py

#table query distinct
echo "DB${SEP}TABLE${SEP}COLUMN${SEP}DISTINCT${SEP}NULLS${SEP}BLANKS${SEP}MAX LENGTH${SEP}MIN_LENGTH" > ${OUTPUT}
for LINE in ${LIST[@]}; do
        DB=`echo ${LINE} | cut -d ${SEP} -f1`
        TABLE=`echo ${LINE} | cut -d ${SEP} -f2`
        COLUMN=`echo ${LINE} | cut -d ${SEP} -f3`
        #DATATYPE=`echo ${LINE} | cut -d ${SEP} -f4`
		#spark-submit simpleprofiler.jar --class simpleProfiler stg readinggroupspc spcnodeid --driver-memory 16G --num-executors 32 --executor-cores 16 --executor-memory 16G
        RUN=`spark-submit --driver-memory 32G --num-executors 64 --executor-cores 16 --executor-memory 16G ${PROFILER_PY} ${DB} ${TABLE} ${COLUMN}>> ${OUTPUT}`
		RES=$?
		if [[ "${RES}" != "0" ]]; then
			exit 1
		fi
done
