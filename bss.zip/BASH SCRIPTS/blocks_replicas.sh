#!/bin/bash
#blk_1579683390* from 192.168.10.91
#blk_1571923583* from 192.168.10.91
#blk_1576381307* from 192.168.10.91
#blk_1582842918* from 192.168.10.93
#blk_1582842909* from 192.168.10.96
#blk_1582842921* from 192.168.10.202
#blk_1582842282* from 192.168.10.203
#blk_1581689174* from 192.168.10.206
#blk_1572755337* from 192.168.10.206
#blk_1575275531* from 192.168.10.206
#
#ixp01bda2dm03
#ixp01bda2dm04
#ixp01bda1dm08 
 
BLOCKS_ARR=(blk_1579683390 blk_1571923583 blk_1576381307 blk_1582842918 blk_1582842909 blk_1582842921 blk_1582842282 blk_1581689174 blk_1572755337 blk_1575275531)
ARR1=(91 93 96 202 203 206)
ARR2=(01 02 03 04 05 06 07 08 09 10 11 12)
SERVER_ARR=(ixp01bda2dm03 ixp01bda2dm04 ixp01bda1dm08)

for REPLICA in ${BLOCKS_ARR}; do
	for i in ${ARR1}; do
		ssh to 192.168.10.${i}
		for j in ${ARR2}; do
			FIND_OUT=`find /u${i} -type f -name "*${REPLICA}*"`
			RES=$?
			if [[ "${RES}" == "0" ]]; then
				for k in ${SERVER_ARR}; do
					scp ${FIND_OUT} ${k}:u${i}
				done
			else
				echo "FIND RETURNED 0 BLOCKS FOR ${REPLICA} IN THE SERVER 192.168.10.$i IN PATH /u${i}. GOING TO THE NEXT ONE."
			fi
		done
	done
done

