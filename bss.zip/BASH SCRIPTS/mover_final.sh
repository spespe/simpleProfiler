#!/bin/bash
##CREATED BY: PIETRO SPERI
##CREATION DATE: 06/08/2018
##CONTACT EMAIL: pietro.speri@sce.com - pietro.speri@infosys.com
##VERSION 0.1
##USAGE: ./mover.sh
##MODIFICATIONS(if any): 06/10/2018 - Added 'wait' command to wait for the end of the cp command. LINES 46-47
##MODIFICATIONS(if any): 06/11/2018 - Added logcut(), timer() and launcher() methods.

INIT_TIMESTAMP=`date '+%Y-%m-%d %H:%M:%S'`
USER=`whoami`
APP_NAME=$(basename ${0})
APP_DIR=`pwd`
FILES_PATH=/dsprojectsprd/SM_APM_N1_PROD/CSDB
INPUT_FOLDER=${FILES_PATH}/INPUT
OUTPUT_FOLDER=${FILES_PATH}/OUTPUT
LANDING_FOLDER=${FILES_PATH}/LANDING/INPUT
LOGINFO=${APP_NAME}_LOG_INFO
LOGERROR=${APP_NAME}_LOG_ERROR
HOSTNAME=`hostname`
EXTENSION=zip
LIMITROWS=3000
INPUT_COMMAND=MASTER_CSDB_INPUT
OUTPUT_COMMAND=MASTER_CSDB_OUTPUT
OUTPUT_NAME=_Output

logger() {
        LEVEL=${1}
		MESSAGE=${2}
		if [[ ${LEVEL} = "ERROR" ]]; then
			echo -e "\033[0;31m ${MESSAGE} \033[m" | tee -a ${LOGERROR} ${LOGINFO}
			exit 1
		elif [[ ${LEVEL} = "DEBUG" ]]; then
			echo -e "\033[0;33m ${MESSAGE} \033[m" | tee -a ${LOGINFO}
		elif [[ ${LEVEL} = "INFO" ]]; then
			echo -e "\033[0;32m ${MESSAGE} \033[m" | tee -a ${LOGINFO}
		elif [[ ${LEVEL} = "VOID" ]]; then
			echo "${MESSAGE}" | tee -a ${LOGINFO}
		else
			echo -e "\033[0;31m THE VALUE SPECIFIED IT IS NOT ERROR, NOR DEBUG, NOR INFO, NOR VOID. PLEASE CORRECT AND TRY AGAIN. \033[m" | tee -a ${LOGERROR}
			exit 1
		fi
}

##CHECKING THE FOLDERS
if [[ ! -d ${INPUT_FOLDER} ]] || [[ ! -d ${LANDING_FOLDER} ]] || [[ ! -d ${OUTPUT_FOLDER} ]]; then
	logger "ERROR" "ERROR ENCOUNTERED: THE FOLDER ${INPUT_FOLDER} or ${LANDING_FOLDER} or ${OUTPUT_FOLDER} DOES NOT EXISTS. PLEASE VERIFY AND TRY AGAIN."
fi

#LOG CUT
logcut(){
	LOGFILE=${1}
	if [[ -f ${1} ]]; then
		TMP_TAIL=`tail -n ${LIMITROWS} ${LOGFILE} > ${LOGFILE}.tmp`
		CHECK=$?
		if [[ ${CHECK} != 0 ]]; then
			logger "ERROR" "ERROR LAUNCHING THE TAIL COMMAND ON THE FILE ${LOGFILE} [LOGCUT METHOD]"
		fi
		MV=`mv ${LOGFILE}.tmp ${LOGFILE}`
		CHECK=$?
		if [[ ${CHECK} != 0 ]]; then
			logger "ERROR" "ERROR LAUNCHING THE MV COMMAND ON THE FILE ${LOGFILE}.tmp [LOGCUT METHOD]"
		fi
	fi
}

#TOTAL TIME CHECK
timer(){
	DURATION=${SECONDS}
	logger "DEBUG" "THE SCRIPT ${APP_NAME} FINISHED SUCCESSFULLY. [TOTAL TIME TAKEN (HH:mm:SS): $((${DURATION} / 3600))HH:$((${DURATION} / 60 % 60))mm:$((${DURATION} % 60))SS] [USER:${USER}] [HOSTNAME:${HOSTNAME}]"
	
}

#LAUNCHER
launcher(){
	FOLDER=${1}
	COMMAND=${2}
	STR_OUTPUT=${3}

	FIND=`find ${FOLDER}/* -prune -type f -name "TransactionLog${STR_OUTPUT}\\.*\\.${EXTENSION}"`
	CHECK=$?
	if [[ ${CHECK} != 0 ]]; then
		logger "ERROR" "ERROR LAUNCHING THE FIND COMMAND - [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${INIT_TIMESTAMP}]"
	fi

	logger "DEBUG" "STARTING THE SCRIPT ${APP_NAME} - [DIRECTORY: ${APP_DIR}] [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${INIT_TIMESTAMP}]"
	#COPYING FILES ONE BY ONE
	for FILE in ${FIND}; do
		START=`date +%s`
		CURRENT_DATE=`date '+%Y-%m-%d %H:%M:%S'`
		LANDING_FILE=${LANDING_FOLDER}/$(basename ${FILE})
		logger "VOID" "COPYING [FILE: ${FILE}] TO [DESTINATION:${LANDING_FOLDER}] - [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${CURRENT_DATE}]"
		CP=`cp -p ${FILE} ${LANDING_FOLDER} &`
		CHECK=$?
		if [[ ${CHECK} != 0 ]]; then
			logger "ERROR" "ERROR COPYING [FILE: ${FILE}] - [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${CURRENT_DATE}]"
		fi
		#WAITING FOR THE END OF CP 
		wait $!
		logger "VOID" "FINISHED COPYING [FILE: ${FILE}] TO [DESTINATION:${LANDING_FOLDER}] - [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${CURRENT_DATE}]"
		##RUNNING COMMAND IN THE CURRENT FOLDER
		logger "VOID" "LAUNCHING THE SCRIPT csdb_runjob.ksh ON THE FILE ${LANDING_FILE} - [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${CURRENT_DATE}]"
		COMM=`/dsprojectsprd/SM_APM_N1_PROD/CSDB/SHL/csdb_runjob.ksh -param pCSDB_Monitor=PROD SM_APM_N1_PROD dsprojectsprd ${COMMAND}`   
		CHECK=$?
		if [[ ${CHECK} != 0 ]]; then
			logger "ERROR" "ERROR LAUNCHING THE COMMAND ON THE FILE ${LANDING_FILE} - [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${CURRENT_DATE}]"
		fi
		END=`date +%s`
		RUNTIME=$((END-START))
		logger "INFO" "SUCCESSFULLY PROCESSED THE FILE ${LANDING_FILE} - [DURATION: $(($RUNTIME/60)) MINUTES AND $(($RUNTIME % 60)) SECONDS] [USER:${USER}] [HOSTNAME:${HOSTNAME}]"
	done
}

#START
SECONDS=0
#INPUT SCRIPT
launcher ${INPUT_FOLDER} ${INPUT_COMMAND} 
#OUTPUT SCRIPT
##launcher ${OUTPUT_FOLDER} ${OUTPUT_COMMAND} ${OUTPUT_NAME}
#TIMER
timer
#LOG CUTS
logcut ${LOGERROR}
logcut ${LOGINFO}
