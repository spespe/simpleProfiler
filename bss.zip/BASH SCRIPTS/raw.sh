#!/bin/bash

READING=(`hadoop fs -ls /data/landing/archive/reading/raw/20181231*/READING.D2* | awk '{print $8}'`)

NUM=0
for el in ${READING[@]}; do
C=`hadoop fs -text ${el} | wc -l`
NUM=$(( ${NUM} + ${C} ))
echo "FILE:${el} - ROW_COUNT:${C} - TOTAL ROWCOUNT: ${NUM}" >> mtr_rdng_raw_check.txt
done

REGISTER=(`hadoop fs -ls /data/landing/archive/reading/raw/20181231*/REGISTERREADING.D2* | awk '{print $8}'`)

NUM=0
for el in ${REGISTER[@]}; do
C=`hadoop fs -text ${el} | wc -l`
NUM=$(( ${NUM} + ${C} ))
echo "FILE:${el} - ROW_COUNT:${C} - TOTAL ROWCOUNT: ${NUM}" >> mtr_rdng_raw_check.txt
done



C=`hadoop fs -text /data/landing/archive/reading/raw/20181231*/REGISTERREADING.D2* | wc -l`
C2=`hadoop fs -text /data/landing/archive/reading/raw/20181231*/READING.D2* | wc -l`
TOT=$(( ${C} + ${C2} ))
echo ${TOT}

C=`hadoop fs -text /data/landing/archive/reading/processed/20181230*/REGISTERREADING.D2* | wc -l`
C2=`hadoop fs -text /data/landing/archive/reading/processed/20181230*/READING.D2* | wc -l`
TOT=$(( ${C} + ${C2} ))
echo ${TOT}

