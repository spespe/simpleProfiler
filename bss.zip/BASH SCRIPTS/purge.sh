#-----------------------------------------------------------------------------------------#
#!/bin/ksh
# Created Date  08/05/2018
# Created By : Pietro Speri <pietro.speri@sce.com> - Srikanth Maddigiri <Srikanth.Maddigiri@sce.com>
# usage : ./purge.sh <DataStage Project Name>
# Example: ./purge.sh ESC_DW_N2_ST
# This Shellscript is used to archive DMS Files from processing directory to archive directory.
# Subdirectoy, using date and timestamp, is created to hold archive files.
# If SCE changes directory name, this script need to be modified accordingly.
#----------------------------------------------------------------------------------------#

DATE=`date '+%Y-%m-%d %H:%M:%S'`
USER=`whoami`
HOSTNAME=`hostname`
LIMITROWS=3000

#----------------------------------Checking Params------------------------------------#
if [ $# -eq 1 ]; then
   PROJECTNAME=$1
   echo "PROJECTNAME = ${PROJECTNAME}"
else
   echo "/nUsage: $0 <PROJECTNAME>/n"
   exit 1
fi
#----------------------------------------------------------------------------------------#

LOGDIR=/projects/DS_PROJ_DIR/${PROJECTNAME}/LOG
DMSARCDIR=/projects/DS_PROJ_DIR/${PROJECTNAME}/ARC/DMS
LOGINFO=${LOGDIR}/arcDMSFiles.log
LOGERROR=${LOGINFO}".ERROR"

if [[ ! -d ${LOGDIR} ]] || [[ ! -d ${DMSARCDIR} ]]; then
	echo "THE FOLDERS [${LOGDIR}] OR [${DMSARCDIR}] DO NOT EXIST. PLEASE VERIFY.  [${PROJECTNAME}] [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${DATE}]" | tee -a ${LOGINFO} ${LOGERROR}
	echo "/nUsage: $0 <PROJECTNAME>/n"
	exit 1
fi

logcut(){
	TMP_TAIL=`tail -n ${LIMITROWS} ${1} > ${1}.tmp`
	CHECK=$?
	if [[ ${CHECK} != 0 ]]; then
		echo "ERROR LAUNCHING THE TAIL COMMAND ON THE FILE ${1} [LOGCUT METHOD]" | tee -a ${LOGINFO} ${LOGERROR}
		exit 1
	fi
	MV=`mv ${1}.tmp ${1}`
	CHECK=$?
	if [[ ${CHECK} != 0 ]]; then
		echo "ERROR LAUNCHING THE MV COMMAND ON THE FILE ${1}.tmp [LOGCUT METHOD]" | tee -a ${LOGINFO} ${LOGERROR}
		exit 1
	fi
}

#Start moving DMS files to archive directory
echo "STARTING. [SCRIPT NAME: ${0}] [ARGUMENT PASSED: ${PROJECTNAME}] [USER:${USER}] [HOSTNAME:${HOSTNAME}] [DATE: ${DATE}]" | tee -a ${LOGINFO}
FIND=`find ${DMSARCDIR}/* -prune -mtime +30 -type f`
CHECK=$?
if [[ ${CHECK} != 0 ]]; then
	echo "ERROR LAUNCHING THE FIND COMMAND [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${DATE}]" | tee -a ${LOGINFO} ${LOGERROR}
	exit 1
fi

for FILE in ${FIND}; do
	KBSIZE=`du -k ${FILE} | cut -f1`
	CHECK=$?
	if [[ ${CHECK} != 0 ]]; then
		echo "ERROR FINDING THE SIZE OF THE FILE ${FILE}" | tee -a ${LOGINFO} ${LOGERROR}
	fi
	echo "REMOVING THE FILE ${FILE} [SIZE KB: ${KBSIZE}]" | tee -a ${LOGINFO}
	RM=`rm -f ${FILE}`
	CHECK=$?
	if [[ ${CHECK} != 0 ]] || [[ -f ${FILE} ]]; then
		echo "ERROR ENCOUNTERED WHILE REMOVING THE FILE ${FILE} [USER:${USER}] [HOSTNAME:${HOSTNAME}] [${DATE}]" | tee -a ${LOGINFO} ${LOGERROR} 
	fi
done

logcut ${LOGERROR}

LOG_DIR_SIZE=`du -m ${LOGDIR}`
echo "FINISHED [USER:${USER}] [HOSTNAME:${HOSTNAME}] [LOG DIRECTORY TOTAL SIZE MB:${LOG_DIR_SIZE}]" | tee -a ${LOGINFO}

logcut ${LOGINFO}

