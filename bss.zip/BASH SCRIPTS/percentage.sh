#!/bin/bash
##CREATED BY: PIETRO SPERI
##CREATION DATE: 10/10/2018
##CONTACT EMAIL: pietro.speri@sce.com - pietro.speri@infosys.com
##VERSION 0.1
##USAGE EXAMPLE: ksh script.ksh [PATTERN] ESPI [DATE1] 2018-10-10 [DATE2] 2018-10-21 [LOG FOLDER] /PATH/TO/LOGS

GREP="^### Job ENDED"
PATTERN=${1}
ERR=0
CORR=0
SEP="|"
DATE=${2}
DATE2=${3}
PROD_LOG_FOLDER=${4}
MAIL=${5}
RECIPIENTS="Santhosh.Kancherla@sce.com pietro.speri@sce.com"
TODAY=`date "+%Y-%m-%d"`

if [[ $# -lt 4 ]]; then
	echo "THE SCRIPT NEEDS AT LEAST 4 ARGUMENTS."
	echo "EXAMPLE: ksh ${0} [PATTERN] ESPI [DATE1] 2018-10-10 [DATE2] 2018-10-21 [LOG FOLDER] /PATH/TO/LOGS"
    exit 1
fi

if [[ ! -d ${4} ]]; then
    echo "THE SPECIFIED FOLDER [${4}] DOES NOT EXIST."
    exit 1
fi

CHECK=`date "+%Y-%m-%d" -d "${DATE}" > /dev/null  2>&1`
RES=$?
CHECK2=`date "+%Y-%m-%d" -d "${DATE2}" > /dev/null  2>&1`
RES2=$?

DAY_BEFORE=`date -d "${DATE2} -1 days" +%Y-%m-%d`

TODAYFORM=$(date -d ${TODAY} +"%Y%m%d")
DATE1FORM=$(date -d ${DATE} +"%Y%m%d")
DATE2FORM=$(date -d ${DATE2} +"%Y%m%d")

if [[ ${RES} != 0 ]] || [[ ${RES2} != 0 ]] || [[ ${#DATE} != 10 ]] || [[ ${#DATE2} != 10 ]] || [[ ! ${DATE} =~ "-" ]] || [[ ! ${DATE2} =~ "-" ]] || [[ ${DATE1FORM} -ge ${DATE2FORM} ]] || [[ ${DATE1FORM} -ge ${TODAYFORM} ]] || [[ ${DATE2FORM} -gt ${TODAYFORM} ]]; then
        echo "THE DATES PASSED ARE NOT IN THE CORRECT FORMAT. PLEASE PROVIDE THE DATE IN THE FORMAT YYYY-MM-DD. THE SECOND DATE HAS TO BE BIGGER THAN THE FIRST ONE. ALSO, THE MAXIMUM DATE AVAILABLE IS TODAY'S DATE (EXCLUDED FROM THE COMPUTATION)."
        exit 1
fi

FINAL_FILE=".PERCENTAGE_${PATTERN}_${DATE}_${DAY_BEFORE}"

if [[ -f ${FINAL_FILE} ]]; then
        rm -f ${FINAL_FILE}
fi

echo "FINDING LOGS FOR JOBS ENDED BETWEEN ${DATE} 00:00:00 AM AND ${DAY_BEFORE} 11:59:59 PM ..PLEASE WAIT UNTIL FINISHED"
LOGS=(`find ${PROD_LOG_FOLDER} -type f -newermt "${DATE}" ! -newermt "${DATE2}" -name "*execution_*" -exec grep -l "${GREP}" {} \;`)

echo "EXECUTION|START_DATE|START_TIME|END_DATE|END_TIME|JOB_NAME|FULL_JOB_NAME|LOG_FILE" > ${FINAL_FILE}

for FILE in ${LOGS[@]}; do
	NAME=`cat ${FILE} | grep "TalendJob:" | head -n1 | cut -d "-" -f 2 | cut -d ":" -f 2`
    START_DATE=`head -n1 ${FILE} | cut -d " " -f6`
    START_TIME=`head -n1 ${FILE} | cut -d " " -f7`
	FULL_JOB_NAME=`head -n2 ${FILE} | tail -n1 | cut -d " " -f3`
	G=`grep "WITH ERROR" ${FILE}`
	RES=$? 
	if [[ ${FULL_JOB_NAME} == *${PATTERN}* ]]; then
		if [[ ${RES} == 0 ]]; then
			END_DATE=`grep ENDED ${FILE} | cut -d " " -f8`
			END_TIME=`grep ENDED ${FILE} | cut -d " " -f9`
			FAILURE_REASON=`grep FATAL ${FILE}`
			((ERR++))
			echo "EXECUTION: ERROR ${SEP} START DATE: ${START_DATE} ${SEP} START TIME: ${START_TIME} ${SEP} END DATE: ${END_DATE} ${SEP} END TIME: ${END_TIME} ${SEP} JOB NAME: ${NAME} ${SEP} FULL JOB NAME: ${FULL_JOB_NAME} ${SEP} LOG FILE: ${FILE} ${SEP} FAILURE REASON: ${FAILURE_REASON} " >> ${FINAL_FILE}
		else
			END_DATE=`grep ENDED ${FILE} | cut -d " " -f7`
			END_TIME=`grep ENDED ${FILE} | cut -d " " -f8`
			((CORR++))
			echo "EXECUTION: SUCCESS ${SEP} START DATE: ${START_DATE} ${SEP} START TIME: ${START_TIME} ${SEP} END DATE: ${END_DATE} ${SEP} END TIME: ${END_TIME} ${SEP} JOB NAME: ${NAME} ${SEP} FULL JOB NAME: ${FULL_JOB_NAME} ${SEP} LOG FILE: ${FILE} " >> ${FINAL_FILE}
		fi
	fi
done

S=`sort -k3,7 -k7 ${FINAL_FILE}`

TOT=$((${ERR}+${CORR}))
FAILURE_RATE=$(echo 100*${ERR}/${TOT} | bc -l)
SUCCESS_RATE=$(echo 100*${CORR}/${TOT} | bc -l)

echo -e "STATS ${PATTERN}:" >> ${FINAL_FILE}
echo -e " - TOTAL JOBS FOUND: ${TOT} - FAILED JOBS: ${ERR} - SUCCEEDED JOBS: ${CORR} - FAILURE RATE: ${FAILURE_RATE}% - SUCCESS RATE: ${SUCCESS_RATE}%" >> ${FINAL_FILE}

if [[ ${MAIL} == "Y" ]] || [[ ${MAIL} == "y" ]]; then
	echo "SENDING EMAIL TO ${RECIPIENTS}"
	MAIL=`echo "Please find attached the talend failures for the time window ${DATE} to ${DAY_BEFORE}" | mutt -s "TALEND JOB FAILURES: ${DATE} - ${DAY_BEFORE}" -a ${FINAL_FILE} ${RECIPIENTS}`
else
	echo "NOT SENDING EMAIL TO ${RECIPIENTS} AS THE EMAIL FLAG WAS NOT SPECIFIED AS Y"
fi

echo "FINISHED."
